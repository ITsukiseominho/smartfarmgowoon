<?php
	include ("../db.php");
	session_destroy();
?>
<meta charset="utf-8">
<script>location.href="/"; </script>