<?php include ("../db.php"); ?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8" />
	<title>IOT 개발</title>
	<link rel="shortcut icon" href="https://bit.ly/3A8Dhdw" />
</head>
<body>
	<?php
	if(isset($_SESSION['userid'])){
		echo "<h2>{$_SESSION['userid']} 님 환영합니다.</h2>";
	?>
	<a href="/member/logout.php"><input type="button" value="로그아웃" /> <a href="/member/mypage.php"><input type="button" value="내 정보 변경" /></a></a>
	<?php 
		}else{
		echo "<script>alert('잘못된 접근입니다.'); history.back();</script>";
	} 
	?>
	<form action="process.php" method="get">
        <p>온도 : <input type="text" name="temp"></p>
        <p>습도 : <input type="text" name="humi"></p>
        <p><input type="submit" /></p>
</form>
</body>
</html>
