<?php
header("Content-Type: text/html;charset=UTF-8");
 
$host = 'localhost';
$user = 'root';
$pw = 'bible5610';
$dbName = 'testdb1';
$mysqli = new mysqli($host, $user, $pw, $dbName);
 
    if($mysqli){
	echo "데이터를 저장하였습니다.<br/>";

	$temp = $_GET['temp'];
	$humi = $_GET['humi'];
	
	echo "<br/>온도 = $temp";
	echo ", ";
	echo "습도 = $humi";
	
	$query = "INSERT INTO tempnhumi (temp, humi) VALUES ('$temp','$humi')";
	mysqli_query($mysqli,$query);

	echo "&nbsp;을 저장하였습니다.";
}

else{
echo "MySQL에 연결되지않았습니다.";
}

mysqli_close($mysqli);
?>